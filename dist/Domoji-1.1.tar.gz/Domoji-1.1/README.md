# Domoji
Emoji Domain Finder in The Command Line - Airplane Project #3

## Setup

Run:
```
pip install domoji

domoji
```

Command line will guide you. Works with terminals that accept Emojis! (Sorry Windows Users)
